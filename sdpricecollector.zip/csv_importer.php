<?php
include_once ('db.php');
session_start();
require 'vendor/autoload.php';
require 'helpers.php';
require 'config.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$spreadsheet = new Spreadsheet();

$GLOBALS['upload_max_filesize'];
$GLOBALS['post_max_size'];
$GLOBALS['max_input_time'];
$GLOBALS['max_execution_time'];

if (isset($_POST["submit"]))
{

    $path_info = pathinfo($_FILES['fileToUpload']['name']);
    $name = upload_csv($path_info);

    $inputFileType = 'Xlsx';
    $inputFileName = 'uploads/'.$name;

    /**  Create a new Reader of the type defined in $inputFileType  **/
    $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader($inputFileType);
    /**  Advise the Reader that we only want to load cell data  **/
    $reader->setReadDataOnly(true);

    $worksheetData = $reader->listWorksheetInfo($inputFileName);

    $i = 0;
    $name_array = [];
    foreach ($worksheetData as $worksheet)
    {

        $sheetName = $worksheet['worksheetName'];
        /**  Load $inputFileName to a Spreadsheet Object  **/
        $reader->setLoadSheetsOnly($sheetName);
        $spreadsheet = $reader->load($inputFileName);

        $worksheet = $spreadsheet->getActiveSheet();
        array_push($name_array, $worksheet->toArray());
        $i++;

    }

    foreach ($name_array as $key => $values)
    {
        $sd_id = [];
        $count = - 1;

        foreach ($GLOBALS['source'] as $kez => $val)
        {
            $count++;
            $source['id'][$count] = $val;
            $source['url'][$count] = [];
        }

        foreach ($values as $key => $value)
        {
            if (!empty($value[0]) && !empty($value[1]) && !empty($value[2]) && !empty($value[3]) && !empty($value[4]) && !empty($value[5]))
            {
                $sql = "SELECT * FROM sd_products_master_table WHERE product_id = '" . $value[0] . "' ";
                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) == 0)
                {
                    $str = preg_replace('/[^0-9]/', '', $value[4]);
                    $sql = "INSERT INTO sd_products_master_table (product_id, sku, url, name, price, category) values ('" . $value[0] . "','" . $value[1] . "', '" . $value[2] . "','" . $value[3] . "', '" . $str . "', '" . $value[5] . "')";

                    if ($conn->query($sql) === true)
                    {
                        echo 'done' . '<br>';
                    }
                }
            }

            $source_url_index = $GLOBALS['start_source_url_count'];

            foreach ($source['url'] as $key => $val)
            {   
                array_push($source['url'][$key], $value[$source_url_index]);
                $source_url_index++;
            }

            if ($value[0] != "N/A" && $value[0] != null)
            {
                array_push($sd_id, $value[0]);
            }
        }

        foreach ($source['id'] as $key => $id)
        {

            foreach ($source['url'][$key] as $key2 => $value)
            {

                if (filter_var($value, FILTER_VALIDATE_URL))
                {
                    $sql = "SELECT * FROM source_product_mapping WHERE source_url = '" . $value . "' ";
                    $result = mysqli_query($conn, $sql);

                    if (mysqli_num_rows($result) == 0)
                    {
                        $sql = "INSERT INTO source_product_mapping (source_id, source_url, sd_product_id) values ('" . $id . "', '" . $value . "', '" . $sd_id[$key2] . "')";

                        if ($conn->query($sql) === true)
                        {
                            echo 'done' . '<br>';
                        }
                    }
                }

            }

        }

    
    }

}

?>
