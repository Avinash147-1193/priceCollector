<?php
include_once ('db.php');
include_once ('config.php');
include_once ('helpers.php');
require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
//error_reporting(0);
$GLOBALS['upload_max_filesize'];
$GLOBALS['post_max_size'];
$GLOBALS['max_input_time'];
$GLOBALS['max_execution_time'];

if (!isset($_GET['limit']))
{
    $sql = "SELECT * FROM source_product_mapping WHERE id > 4637";
}
else
{
    $sql = "SELECT * FROM source_product_mapping LIMIT " . $_GET['limit'] . " ";
}

$result = mysqli_query($conn, $sql);

$arr = [];

while ($row = mysqli_fetch_assoc($result))
{
    $arr[] = $row;
}

foreach ($arr as $key => $value)
{
    $api = get_url_api($value['source_id']);
    $product_url = $value['source_url'];
    $price = get_request_response($api, $product_url);
    $price = !empty($price->sellingPrice) ? $price->sellingPrice : '"N/A"';
    
    $sqlTemp = "SELECT * FROM mapped_prices WHERE source_id = '" . $value['source_id'] . "' AND created_at = '" . date("d-m-Y") . "' AND sd_product_id = '" . $value['sd_product_id'] . "' ";
    $result = mysqli_query($conn, $sqlTemp);

    if (mysqli_num_rows($result) == 0 )
    {   
        $sql = "INSERT INTO mapped_prices (source_id, source_url, sd_product_id, price, created_at) VALUES ('" . $value['source_id']. "', '" . $value['source_url']. "', '" . $value['sd_product_id']. "', '" . $price . "', '" . date("d-m-Y") . "')  ";
        try {
            $result = mysqli_query($conn, $sql);
            if(!$result) {
                throw new customException('Null');
            }
        }
        catch (customException $e) {

        }
        
    }
}
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $GLOBALS['baseUrl'] . 'mail.php');
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Send the request
$response = curl_exec($ch);
curl_close($ch);
echo "$response";
?>
