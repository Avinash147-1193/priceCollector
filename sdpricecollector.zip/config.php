<?php

/*
|--------------------------------------------------------------------------
|Environment variables
|--------------------------------------------------------------------------
|This section contains API end points for different source websites
| 
|
*/

$GLOBALS['environment']['development'] = 1;
$GLOBALS['environment']['testing'] = 2;
$GLOBALS['environment']['production'] = 3;

$GLOBALS['current_environment'] = 1;

if ($GLOBALS['current_environment'] == $GLOBALS['environment']['development'])
{
    $GLOBALS['baseUrl'] = "http://localhost/sdpricecollector/";
}
elseif ($GLOBALS['current_environment'] == $GLOBALS['environment']['testing'])
{
    $GLOBALS['baseUrl'] = " ";
}
elseif ($GLOBALS['current_environment'] == $GLOBALS['environment']['production'])
{
    $GLOBALS['baseUrl'] = "pi.shakedeal.com/";
}

/*
|--------------------------------------------------------------------------
|Source id ends here
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
|API for different sources
|--------------------------------------------------------------------------
|This section contains API end points for different source websites
| 
|
*/

$GLOBALS['url_based_crawling'] = "https://pkyb8ljeo6.execute-api.us-east-2.amazonaws.com/prod/?source_id=";

/*
|--------------------------------------------------------------------------
|API ends here
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
|Source ids
|--------------------------------------------------------------------------
|This section contains API end points for different source websites
| 
|
*/

$GLOBALS['source']['moglix_source_id'] = 1;
$GLOBALS['source']['industryBuying_source_id'] = 4;
$GLOBALS['source']['flipkart_source_id'] = 5;
$GLOBALS['source']['nowPurchase_source_id'] = 6;

/*
|--------------------------------------------------------------------------
|Source id ends here
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
|email ids
|--------------------------------------------------------------------------
|This section contains API end points for different source websites
| 
|
*/
//pi.notifications@shakedeal.com
$GLOBALS['emails'] = "pi.notifications@shakedeal.com";
$GLOBALS['from_email'] = "noreply@shakedeal.com";
$GLOBALS['email_subject'] = "SD PI Alert";

/*
|--------------------------------------------------------------------------
|Source id ends here
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
|DB Config credentaials
|--------------------------------------------------------------------------
|This section contains API end points for different source websites
| 
|
*/
$GLOBALS['servername'] = "localhost";
$GLOBALS['username'] = "root";
$GLOBALS['password'] = "";
$GLOBALS['dbname'] = "sdpi";
/*
|--------------------------------------------------------------------------
|DB Config credentaials ends here
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
|CSV file starting index of source product URLs
|--------------------------------------------------------------------------
|This section contains API end points for different source websites
| 
|
*/
$GLOBALS['start_source_url_count'] = 6;
/*
|--------------------------------------------------------------------------
|
|--------------------------------------------------------------------------
*/


/*
|--------------------------------------------------------------------------
|Mail numer of product comparision limit
|--------------------------------------------------------------------------
|
| 
|
*/
$GLOBALS['max_product_listing'] = 100;
/*
|--------------------------------------------------------------------------
|DB Config credentaials ends here
|--------------------------------------------------------------------------
*/


/*
|--------------------------------------------------------------------------
|PHP ini settings
|--------------------------------------------------------------------------
|
| 
|
*/
$GLOBALS['upload_max_filesize'] = ini_set('upload_max_filesize', '50M');
$GLOBALS['post_max_size'] = ini_set('post_max_size', '50M');
$GLOBALS['max_input_time'] = ini_set('max_input_time', 0);
$GLOBALS['max_execution_time'] = ini_set('max_execution_time', 0);
/*
|--------------------------------------------------------------------------
|DB Config credentaials ends here
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
|SendGrid API key
|--------------------------------------------------------------------------
|
| 
|
*/
$GLOBALS['sendgrid_api'] = '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';
/*
|--------------------------------------------------------------------------
|SendGrid API ends here
|--------------------------------------------------------------------------
*/


/*
|--------------------------------------------------------------------------
|SMTP Credentials
|--------------------------------------------------------------------------
|
| 
|
*/
$GLOBALS['smtp_username']  = 'AKIAXNTRR6VKGZUT4YG4';
$GLOBALS['smtp_password']  = 'BKDORqAVTEswmx1Vw8M0mw95Xq1PHNXIS7c10/2YY9RJ';
$GLOBALS['smtp_host']    = 'email-smtp.ap-south-1.amazonaws.com';
$GLOBALS['smtp_port']    = 587;
/*
|--------------------------------------------------------------------------
|SMTP API ends here
|--------------------------------------------------------------------------
*/



/*
|--------------------------------------------------------------------------
|Miler option selection
|--------------------------------------------------------------------------
|
| 
|
*/
$GLOBALS['sendgrid_mailer'] = 1;
$GLOBALS['php_mailer'] = 2;

$GLOBALS['current_mailer'] = 2;
/*
|--------------------------------------------------------------------------
|SendGrid API ends here
|--------------------------------------------------------------------------
*/

?>
