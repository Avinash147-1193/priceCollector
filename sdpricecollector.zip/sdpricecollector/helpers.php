<?php
require 'vendor/autoload.php';
use GuzzleHttp\Client;
use GuzzleHttp\Promise;
error_reporting(0);

$GLOBALS['upload_max_filesize'];
$GLOBALS['post_max_size'];
$GLOBALS['max_input_time'];
$GLOBALS['max_execution_time'];

// ********************static block starts here***************

//* uploads CSV to directory
function upload_csv($info)
{
    $ext = $info['extension']; // get the extension of the file
    $t = time();
    $randomNumber = rand(15, 3500);
    $newname = $t . $randomNumber . "." . $ext;
    $target = 'uploads/' . $newname;
    move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $target);
    return $newname;
}

//* parse the uploaded CSV and convert it's input to array
function parse_csv($newname)
{
    $inputFileType = 'Xlsx';
    $inputFileName = 'uploads/' . $newname;

    /**  Create a new Reader of the type defined in $inputFileType  **/
    $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader($inputFileType);

    /**  Advise the Reader that we only want to load cell data  **/
    $reader->setReadDataOnly(true);
    $worksheetData = $reader->listWorksheetInfo($inputFileName);

    $i = 0;
    $name_array = [];
    foreach ($worksheetData as $worksheet)
    {
        $sheetName = $worksheet['worksheetName'];

        /**  Load $inputFileName to a Spreadsheet Object  **/
        $reader->setLoadSheetsOnly($sheetName);
        $spreadsheet = $reader->load($inputFileName);

        $worksheet = $spreadsheet->getActiveSheet();
        array_push($name_array, $worksheet->toArray());
        $i++;
    }
    return $name_array;
}

function get_url_api($source_id)
{
    $api = $GLOBALS['url_based_crawling'] . $source_id . '&url=';
    return $api;
}

/**This function sends data to Lambda function & returns the response **/
function get_request_response($api, $product_url)
{
    $client = new \GuzzleHttp\Client();
    $url = $api.$product_url;
    $request = $client->get($url);
    $response = $request->getBody()->getContents();
    $response = json_decode($response);
    return $response;
}

// ********************static block starts here***************

?>
