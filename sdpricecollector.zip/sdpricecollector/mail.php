<?php
error_reporting(0);
include_once ('db.php');
include_once ('config.php');
include_once ('helpers.php');
require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$temp = 0;

if (!isset($_GET['date']))
{
    $_GET['date'] = date('d-m-Y');
}

if (isset($_GET['date']))
{
    $temp = 1;

    $GLOBALS['upload_max_filesize'];
    $GLOBALS['post_max_size'];
    $GLOBALS['max_input_time'];
    $GLOBALS['max_execution_time'];

    $date = $_GET['date'];

    $sql = "SELECT * FROM sd_products_master_table";
    $result = mysqli_query($conn, $sql);

    $data['sd_product_id'] = [];
    $data['category'] = [];
    $data['sku'] = [];
    $data['name'] = [];
    $data['price'] = [];
    $data['url'] = [];

    while ($row = mysqli_fetch_assoc($result))
    {
        array_push($data['sd_product_id'], $row['product_id']);
        array_push($data['url'], $row['url']);
        array_push($data['price'], $row['price']);
        array_push($data['name'], $row['name']);
        array_push($data['sku'], $row['sku']);
        array_push($data['category'], $row['category']);
    }

    $source_count = count($GLOBALS['source']);

    for ($i = 0;$i < $source_count;$i++)
    {
        $sources['price'][$i] = [];
        $sources['url'][$i] = [];
    }

    $sd_price_count = 0;
    foreach ($data['sd_product_id'] as $key => $id)
    {
        $count = 0;
        foreach ($GLOBALS['source'] as $kez => $value)
        {
            $sql = "SELECT * FROM mapped_prices WHERE source_id = '" . $value . "' AND created_at = '$date' AND sd_product_id = '$id' AND price < '" . $data['price'][$key] . "'";
            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0)
            {
                while ($row = mysqli_fetch_assoc($result))
                {
                    array_push($sources['price'][$count], $row['price']);
                    array_push($sources['url'][$count], $row['source_url']);
                }
            }
            else
            {
                array_push($sources['price'][$count], null);
                array_push($sources['url'][$count], $row['source_url']);
            }
            $count++;
        }
        $sd_price_count++;
    }

}

function getIndexInSortedArray($arr, $n, $element)
{
    sort($arr);
    $result = array_search($element, $arr);
    return ($result + 1);
}

$cellArr = ["A", "B", "C", "D", "E", "F", "G", "H","I","J"];
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

$template = '
<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<style>
body {
 background-color: #f6f6f6;
 font-family: sans-serif;
 -webkit-font-smoothing: antialiased;
 font-size: 14px;
 line-height: 1.4;
 margin: 0;
 padding: 0;
 -ms-text-size-adjust: 100%;
 -webkit-text-size-adjust: 100%;
}
table {
  color: #5b5e5d;
  border-collapse: separate;
  mso-table-lspace: 0pt;
  mso-table-rspace: 0pt;
  width: 100%;
}
table td {
 font-family: sans-serif;
 font-size: 14px;
 vertical-align: top;
}
table td a {
  text-decoration: none;
  color: #446296;
}
/* -------------------------------------
BODY & CONTAINER
------------------------------------- */ 
.body {
 background-color: #f6f6f6;
 width: 100%;
}
/* Set a max-width, and make it display as block so it will automatically stretch to that width, but will also shrink down on a phone or something */

.container {
 display: block;
 margin: 0 auto !important;
 /* makes it centered */
 max-width: 680px;
 padding: 10px;
 width: 680px;
}
.danger-price-1{
    background-color: #fa7575;
}
.danger-price-2{
    background-color: #faacac;
}
.danger-price-3{
    background-color: #ffd4d4;
}

.danger-price-4{
    background-color: #fff2f2;
}

.success-price{
  background-color: #74cfb0;
}
/* This should also be a block element, so that it will fill 100% of the .container */

.content {
 box-sizing: border-box;
 display: block;
 margin: 0 auto;
 max-width: 680px;
 padding: 10px;
}
/* -------------------------------------
HEADER, FOOTER, MAIN
------------------------------------- */

.main {
 background: #fff;
 border-radius: 3px;
 width: 100%;
}
.wrapper {
 box-sizing: border-box;
 padding: 20px;
}
.footer {
 clear: both;
 padding-top: 10px;
 text-align: center;
 width: 100%;
}
.footer td,
.footer p,
.footer span,
.footer a {
 color: #999999;
 font-size: 12px;
 text-align: center;
}
hr {
 border: 0;
 border-bottom: 1px solid #f6f6f6;
 margin: 20px 0;
}
/* -------------------------------------
RESPONSIVE AND MOBILE FRIENDLY STYLES
------------------------------------- */

@media only screen and (max-width: 620px) {
 table[class=body] .content {
   padding: 0 !important;
 }
 table[class=body] .container {
   padding: 0 !important;
   width: 100% !important;
 }
}
</style>
</head>
<body class="">
<table  class="body">
<tr>
<td>&nbsp;</td>
<td class="container">
<div class="content">
<!-- START CENTERED WHITE CONTAINER -->
<table class="main">
<!-- START MAIN CONTENT AREA -->
<tr>
<td class="wrapper">
<table style="margin-left: -27px !important">

<span style="font-size: 12pt;"><span style="font-size: 10pt;"><img src="https://cdn.shakedeal.com/images/logos/2/ShakeDealLogo.png?t=1542723379" alt="" width="132" height="35" />
<h4 > ShakeDeal product price mapping & crawling is completed. Please go through the details in the below table.</h4>
<caption>Mapping Details</caption>
</span></span>
<tr>
<th style="border:1px solid black;">Sl no.</th>
<th style="border:1px solid black;">Product ID</th>
<th style="border:1px solid black;">Product name</th>
<th style="border:1px solid black;">SKU</th>
<th style="border:1px solid black;">Catgeory</th>
<th style="border:1px solid black;">ShakeDeal price</th>
<th style="border:1px solid black;">Moglix price</th>
<th style="border:1px solid black;">IndustryBuying price</th>
<th style="border:1px solid black;">Flipkart Price</th>
<th style="border:1px solid black;">NowPurchase Price</th>
</tr>
';
$sheet->setCellValue('A1', 'Sl No.');
$sheet->setCellValue('B1', 'Product ID');
$sheet->setCellValue('C1', 'Product Name');
$sheet->setCellValue('D1', 'SKU');
$sheet->setCellValue('E1', 'Category');
$sheet->setCellValue('F1', 'Shakedeal Price');
$sheet->setCellValue('G1', 'Moglix Price');
$sheet->setCellValue('H1', 'IndustryBuying Price');
$sheet->setCellValue('I1', 'Flipkart Price');
$sheet->setCellValue('J1', 'NowPurchase Price');

if ($temp == 1)
{

    $count = 1;
    $cellIndex = 0;
    foreach ($data["price"] as $key => $price)
    {

        $null_checker = 0;
        $price_checker = 0;
        $colorArr = [];
        foreach ($sources["price"] as $key2 => $value)
        {
            if ($value[$key] != null)
            {
                $null_checker = 1;
            }

            if (intval($value[$key]) < intval($data["price"][$key]) && $value[$key] != null)
            {
                $price_checker = 1;
            }
        }

        if ($null_checker != 0 && $price_checker != 0)
        {
            $count++;

            if ($count <= $GLOBALS['max_product_listing'])
            {
                $template .= '<tr class="row100 body">';
                $template .= '<td class="cell100 column1" width = "5%">' . $count . '</td><td class="cell100 column2">' . $data["sd_product_id"][$key] . '</td><td class="cell100 column2">' . $data["name"][$key] .'</td><td class="cell100 column2">' . $data["sku"][$key] . '</td><td class="cell100 column2">' . $data["category"][$key] .' </td><td class="cell100 column2"><a href="' . $data["url"][$key] . '" target="_blank"> ' . $data["price"][$key] . '</a></td>';
            }

            $sheet->setCellValue((string)$cellArr[$cellIndex] . (string)($count) , $count - 1);
            $sheet->setCellValue((string)$cellArr[$cellIndex + 1] . (string)($count) , $data["sd_product_id"][$key]);
            $sheet->setCellValue((string)$cellArr[$cellIndex + 2] . (string)($count) , $data["name"][$key]);
            $sheet->setCellValue((string)$cellArr[$cellIndex + 3] . (string)($count) , $data["sku"][$key]);
            $sheet->setCellValue((string)$cellArr[$cellIndex + 4] . (string)($count) , $data["category"][$key]);
            $sheet->setCellValue((string)$cellArr[$cellIndex + 5] . (string)($count) , $data["price"][$key]);
            $sheet->getCell((string)$cellArr[$cellIndex + 5] . (string)($count))->getHyperlink()
                ->setUrl($data["url"][$key]);
            foreach ($sources['price'] as $key3 => $value)
            {

                if ($value[$key] != null || $value[$key] != "")
                {
                    array_push($colorArr, $value[$key]);
                }
            }

            $url_array_index_count = 0;
            foreach ($sources['price'] as $key3 => $value)
            {

                if ($value[$key] == null || $value[$key] == "")
                {
                    if ($count <= $GLOBALS['max_product_listing'])
                    {
                        $template .= '<td class="cell100 column2">N/A </td>';
                    }
                    $sheet->setCellValue((string)$cellArr[$url_array_index_count + 6] . (string)($count) , 'N/A');
                }
                else
                {
                    $sheet->setCellValue((string)$cellArr[$url_array_index_count + 6] . (string)($count) , $value[$key]);
                    $sheet->getCell((string)$cellArr[$url_array_index_count + 6] . (string)($count))->getHyperlink()
                        ->setUrl($sources["url"][$url_array_index_count][$key]);

                    if ($count <= $GLOBALS['max_product_listing'])
                    {
                        $template .= '<td class="cell100 column3 ';
                    }

                    if (intval($value[$key]) < intval($data["price"][$key]))

                    {
                        $index = getIndexInSortedArray($colorArr, count($colorArr) , $value[$key]);

                        if ($count <= $GLOBALS['max_product_listing'])
                        {
                            $template .= 'danger-price-' . $index;
                        }

                        switch ($index)
                        {
                            case '1':
                                $colorVal = 'fa7575';
                            break;
                            case '2':
                                $colorVal = 'faacac';
                            break;
                            case '3':
                                $colorVal = 'ffd4d4';
                            break;
                            case '4':
                                $colorVal = 'fff2f2';
                            break;
                            default:
                            break;
                        }
                        $sheet->getStyle((string)$cellArr[$url_array_index_count + 6] . (string)($count))->getFill()
                            ->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
                            ->getStartColor()
                            ->setARGB((string)$colorVal);
                    }

                    if ($count <= $GLOBALS['max_product_listing'])
                    {
                        $template .= ' "> <a href=" ' . $sources["url"][$url_array_index_count][$key] . '" target="_blank" style="color:black"> ' . $value[$key] . ' </a></td>';
                    }
                }

                $url_array_index_count++;
            }

            if ($count <= $GLOBALS['max_product_listing'])
            {
                $template .= '</tr>';
            }
            $cellIndex = 0;
        }

    }
}

$template .= '
</table>
<hr /><a href="https://www.shakedeal.com/all-categories" target="_blank"><img src="https://crm.shakedeal.com/media/public/Emailer.jpg"  alt="Shakedeal Categories" title="Shakedeal Categories" style="display:block"  width="700px" height="170px" /></a></span><span style="font-size: 12pt;"></span>
<hr />                            
<hr />

<div style="text-align: center;"><a href="https://www.facebook.com/shakedeal" target="_blank" rel="noopener"><img src="https://crm.shakedeal.com/media/public/facebook.png" height="30px" width="30px" /></a> <a href="https://www.linkedin.com/company/shakedeal" target="_blank" rel="noopener"><img src="https://crm.shakedeal.com/media/public/Linkedin.png" height="30px" width="30px" /></a> <a href="https://twitter.com/shakedeal" target="_blank" rel="noopener"><img src="https://crm.shakedeal.com/media/public/Twitter.png" height="30px" width="30px" /></a> <a href="https://www.instagram.com/shakedeal/" target="_blank" rel="noopener"><img src="https://crm.shakedeal.com/media/public/instagram-icon.png" height="30px" width="30px" /></a> <a href="https://www.pinterest.com/shakedeal1591/" target="_blank" rel="noopener"><img src="https://crm.shakedeal.com/media/public/pinterest.png" height="30px" width="30px" /></a> <a href="https://www.youtube.com/channel/UCjkHdn9RBKxmgFQ1vNGfxgw" target="_blank"><img src="https://crm.shakedeal.com/media/public/youtube.png"  height="30px" width="30px"></a>&nbsp;</div>
</td>
</tr>
</table>
</td>
</tr>
<!-- END MAIN CONTENT AREA -->


</table>
<!-- START FOOTER -->
<div class="footer">
<table border="0" cellpadding="0" cellspacing="0">
<tr>
<td class="content-block">
<span></span>
</td>
</tr>
</table>
</div>
<!-- END FOOTER -->
<!-- END CENTERED WHITE CONTAINER -->
</div>
</td>
<td>&nbsp;</td>
</tr>
</table>
</body>
</html>';

$writer = new Xlsx($spreadsheet);
$filename = time() . '-sd-pi.xlsx';
$attachment = './attachments/' . $filename;
$writer->save($attachment);

$to = $GLOBALS['emails'];
$from = $GLOBALS['from_email'];
$subject = $GLOBALS['email_subject'];

if ($GLOBALS['current_mailer'] == $GLOBALS['sendgrid_mailer'])
{
    require 'vendor/autoload.php';
    $email = new \SendGrid\Mail\Mail();

    $content = file_get_contents($attachment);

    $attachment = new \SendGrid\Mail\Attachment();
    $attachment->setContent($content);
    $attachment->setType("application/excel");
    $attachment->setFilename("SD-PI.xlsx");
    $attachment->setDisposition("attachment");

    $email->addAttachment($attachment);
    $email->setFrom($from, $subject);
    $email->setSubject($subject);
    $email->addTo($to, "Notification-Shakedeal");
    $email->addContent("text/html", $template);

    $sendgrid = new \SendGrid($GLOBALS['sendgrid_api']);
    try
    {
        $response = $sendgrid->send($email);
        if ($response)
        {
            echo 'Email has been sent successfully.';
        }
        else
        {
            echo 'Email sending failed.';
        }
    }
    catch(Exception $e)
    {
        echo 'Caught exception: ', $e->getMessage() , "\n";
    }
}

if ($GLOBALS['current_mailer'] == $GLOBALS['php_mailer'])
{
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    if (mail($to, $subject, $template, $headers))
    {
        echo 'Email has been sent successfully.';
    }
    else
    {
        echo 'Email sending failed.';
    }
}

?>
