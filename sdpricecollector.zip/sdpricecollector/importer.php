<?php
include_once ('db.php');
require 'vendor/autoload.php';
require 'helpers.php';
require 'config.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$spreadsheet = new Spreadsheet();

$GLOBALS['upload_max_filesize'];
$GLOBALS['post_max_size'];
$GLOBALS['max_input_time'];
$GLOBALS['max_execution_time'];

if (isset($_POST["submit"]))
{

    $path_info = pathinfo($_FILES['fileToUpload']['name']);
    $name = upload_csv($path_info);

    $inputFileType = 'Xlsx';
    $inputFileName = 'uploads/'.$name;

    /**  Create a new Reader of the type defined in $inputFileType  **/
    $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader($inputFileType);
    /**  Advise the Reader that we only want to load cell data  **/
    $reader->setReadDataOnly(true);

    $worksheetData = $reader->listWorksheetInfo($inputFileName);

    $i = 0;
    $name_array = [];

    foreach ($worksheetData as $worksheet)
    {

        $sheetName = $worksheet['worksheetName'];
        /**  Load $inputFileName to a Spreadsheet Object  **/
        $reader->setLoadSheetsOnly($sheetName);
        $spreadsheet = $reader->load($inputFileName);

        $worksheet = $spreadsheet->getActiveSheet();
        array_push($name_array, $worksheet->toArray());
        $i++;

    }

    foreach ($name_array as $key => $values)
    {
        

        foreach ($values as $key => $value)
        {
            $sql = "UPDATE sd_products_master_table SET sku = '" . $value[4] . "', category = '" . $value[5] . "' WHERE product_id = '".$value[0]."' AND url = '".$value[1]."' ";

            if ($conn->query($sql) === true)
            {
                echo 'done' . '<br>';
            }
            
        }



    
    }

}

?>
