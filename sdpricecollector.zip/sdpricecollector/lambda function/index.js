exports.handler = function(event, context, callback) {
    const axios = require('axios');
    const cheerio = require('cheerio');
    const fs = require('fs');
    let url = event.url;
    let sourceId = event.source_id;
    let gst_percent = 0.18;

    let multi_class_sources = {
        '2': 'industryBuyingFirst'
    }

    let gst_excluded_sources = {
        '4': 'nowPurchase'
    }

    function sourcePriceClass() {
        let price_classes = {
            'flipkart': '._3qQ9m1',
            'nowPurchase': '.productSalePrice',
            'moglix': '.f-size-xs-22',
            'industryBuyingFirst': '.AH_PricePerPiece, .mainPrice',
        }

        let sourceId_mapping = {
            '1': 'moglix',
            '2': 'industryBuyingFirst',
            '3': 'flipkart',
            '4': 'nowPurchase'
        }

        for (var attributename in sourceId_mapping) {
            if (sourceId == attributename) {
                getWebsiteContent(url, price_classes[sourceId_mapping[attributename]], sourceId);
            }
        }
    }

    /** For sources not including GST, this function calibrate the price**/
    function gstIncluder(price, sourceId) {
        if (sourceId in gst_excluded_sources) {
            price = (gst_percent * parseInt(price)) + parseInt(price);
            return price;
        } else {
            return price;
        }
    }

    function scrapPrice(sourceRate, sourceId) {
        if (sourceRate == '' || sourceRate == undefined) {
            sourceRate = "N/A";
        } else {
            sourceRate = gstIncluder(sourceRate, sourceId);
        }

        let metadata = {
            "sellingPrice": sourceRate,
        }
        return metadata;
    }

    const getWebsiteContent = async (url, class_name, sourceId) => {
        try {
            const response_1 = await axios.get(url);
            let $ = cheerio.load(response_1.data);

            if (!(sourceId in multi_class_sources)) {

                let sourceRate = $(class_name).text().replace(/\D/g, '');
                let metadata = scrapPrice(sourceRate, sourceId);
                callback(null, metadata);

            } else {

                let temp = 0;
                var classArr = class_name.split(',');

                for (var i = çlassArr.length - 1; i >= 0; i--) {
                    $(classArr[i]).map((i, el) => {
                        temp = 1;
                    });
                    if (temp == 1) {
                        let sourceRate = $(classArr[i]).text().replace(/\D/g, '');
                        let metadata = scrapPrice(sourceRate, sourceId);
                        callback(null, metadata);
                    }
                }

            }
        } catch (error) {
            console.error(error);
        }
    }

    sourcePriceClass();
};