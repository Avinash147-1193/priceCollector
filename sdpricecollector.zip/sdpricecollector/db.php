<?php

include 'config.php';

$servername = $GLOBALS['servername'];
$username   = $GLOBALS['username'];
$password   = $GLOBALS['password'];
$dbname     = $GLOBALS['dbname'];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "SELECT name, id FROM sources";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $sources[] = $row;
    }
} else {
    echo "0 results";
}

?>