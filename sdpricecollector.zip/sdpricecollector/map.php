<?php
include_once ('db.php');
include_once ('config.php');
include_once ('helpers.php');
require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
error_reporting(0);
$GLOBALS['upload_max_filesize'];
$GLOBALS['post_max_size'];
$GLOBALS['max_input_time'];
$GLOBALS['max_execution_time'];

if (!isset($_GET['limit']))
{
    $sql = "SELECT * FROM source_product_mapping";
}
else
{
    $sql = "SELECT * FROM source_product_mapping  LIMIT " . $_GET['limit'] . " ";
}

$result = mysqli_query($conn, $sql);

$arr = [];

while ($row = mysqli_fetch_assoc($result))
{
    $arr[] = $row;
}

$results['price'] = [];
$results['source_id'] = [];
$results['source_url'] = [];
$results['sd_product_id'] = [];
$promises = [];
$ids = [];

foreach ($arr as $key => $value)
{
    $api = get_url_api($value['source_id']);
    $product_url = $value['source_url'];
    array_push($promises, get_request_response($api, $product_url));
    array_push($results['source_id'], $value['source_id']);
    array_push($results['source_url'], $value['source_url']);
    array_push($results['sd_product_id'], $value['sd_product_id']);
}

foreach ($promises as $key => $promise)
{

    if (isset($promise->sellingPrice))
    {
        array_push($results['price'], $promise->sellingPrice);
    }
    else
    {
        array_push($results['price'], null);
    }

}

$sql = "INSERT INTO mapped_prices (source_id, source_url, sd_product_id, price, created_at) VALUES ";
$it = new ArrayIterator($results['price']);
// a new caching iterator gives us access to hasNext()
$cit = new CachingIterator($it);

foreach ($cit as $value)
{
    $sqlTemp = "SELECT * FROM mapped_prices WHERE source_id = '" . $results['source_id'][$cit->key() ] . "' AND created_at = '" . date("d-m-Y") . "' AND sd_product_id = '" . $results['sd_product_id'][$cit->key() ] . "' ";
    $result = mysqli_query($conn, $sqlTemp);

    if (mysqli_num_rows($result) == 0)
    {
        $sql .= "('" . $results['source_id'][$cit->key() ] . "', '" . $results['source_url'][$cit->key() ] . "', '" . $results['sd_product_id'][$cit->key() ] . "', '" . $cit->current() . "', '" . date("d-m-Y") . "')";
        // if there is another array member, add a comma
        if ($cit->hasNext())
        {
            $sql .= ",";
        }
    }
}

if ($conn->query($sql))
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $GLOBALS['baseUrl'] . 'mail.php');
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Send the request
    $response = curl_exec($ch);
    curl_close($ch);
    echo "$response";
}
?>
