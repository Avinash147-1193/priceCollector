<?php include "../config.php" ?>
<!DOCTYPE html>
<html>
   <head>
      <title>Searched results</title>
      <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
      <script src="../assets/js/jquery.min.js"></script>
      <script src="../assets/js/bootstrap.min.js"></script>
      <link rel="stylesheet" href="../assets/css/style.css">
   </head>
   <body class="custom">
      <div class="testbox container" style="width: 50%">
         <form action="../importer.php" method="post"  enctype= "multipart/form-data" onsubmit="return validateForm()">
            <div class="form-group" id="upload_file">
               <label for="exampleFormControlTextarea1">Upload Excel file</label>
               <div class="custom-file">
                  <input type="file" class="custom-file-input" id="fileToUpload" name="fileToUpload" required>
                  <label class="custom-file-label" for="customFile">Choose file</label>
               </div>
            </div>
            <div class="form-group ">
               <button type="submit" name="submit" class="btn btn-primary center-block">Submit</button>
            </div>
         </form>
      </div>
   </body>
   <script>
      $(".custom-file-input").on("change", function() {
        var fileName = $(this).val().split("\\").pop();
        $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
      });
   </script>
</html>